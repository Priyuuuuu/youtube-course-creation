import streamlit as st
from googleapiclient.discovery import build
from youtube_transcript_api import YouTubeTranscriptApi
import google.generativeai as genai
from moviepy.editor import ImageClip, concatenate_videoclips, AudioFileClip
from pptx import Presentation
from gtts import gTTS
import tempfile
import os
import json
import pythoncom
import comtypes.client
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate

# Set up YouTube Data API
API_KEY = "AIzaSyAe9nQVoc9KuZbljckF-n-tpNjQ2CvqTn0"  # Replace with your actual YouTube API key
youtube = build("youtube", "v3", developerKey=API_KEY)

# Configure the Gemini API
gemini_key = "AIzaSyDWZeuJjo2RemQUoGbbOcvE5hpXMo92Fv8"  # Replace with your actual Gemini API key
genai.configure(api_key=gemini_key)
model = genai.GenerativeModel('models/gemini-1.0-pro')

# Langchain Google API Key setup
os.environ["GOOGLE_API_KEY"] = "AIzaSyDWZeuJjo2RemQUoGbbOcvE5hpXMo92Fv8"

# Step 1: Function to search YouTube and fetch transcripts
def youtube_search(query, max_results=5):
    results = []
    next_page_token = None

    while len(results) < max_results:
        search_results = youtube.search().list(
            q=query,
            part="snippet",
            maxResults=10,
            pageToken=next_page_token,
            type="video",
            order="relevance"
        ).execute()

        for item in search_results['items']:
            video_id = item['id']['videoId']
            if has_transcript(video_id):
                results.append({
                    "title": item['snippet']['title'],
                    "url": f"https://www.youtube.com/watch?v={video_id}",
                    "video_id": video_id
                })
            if len(results) >= max_results:
                break

        next_page_token = search_results.get('nextPageToken')
        if not next_page_token:
            break

    return results

def has_transcript(video_id):
    try:
        YouTubeTranscriptApi.get_transcript(video_id)
        return True
    except Exception:
        return False

def get_transcript(video_id):
    try:
        transcript = YouTubeTranscriptApi.get_transcript(video_id)
        return " ".join([t['text'] for t in transcript])
    except Exception as e:
        st.error(f"Error getting transcript: {e}")
        return None

def summarize_transcripts(combined_transcript):
    prompt = f"Summarize the following content into a concise transcript: {combined_transcript}"
    response = model.generate_content(prompt)
    return response.text

# Step 2: Convert summarized text to structured JSON suitable for PowerPoint
PROMPT = """
Summarize the input text and arrange it in an array of JSON objects to be suitable for a PowerPoint presentation.
Determine the needed number of JSON objects (slides) based on the length of the text.
Each key point in a slide should be limited to up to 10 words.
Consider a maximum of 5 bullet points per slide.
Return the response as an array of JSON objects.
The first item in the list must be a JSON object for the title slide.
This is a sample of such a JSON object:
{{
    "id": 1,
    "title_text": "My Presentation Title",
    "subtitle_text": "My presentation subtitle",
    "is_title_slide": "yes"
}}
And here is a sample of JSON data for slides:
{{
    "id": 2,
    "title_text": "Slide 1 Title",
    "text": ["Bullet 1", "Bullet 2"]
}}
Make sure the JSON object is correct and valid. Don't output explanations. I just need the JSON array as output.
"""

def generate_ppt_json(input_text: str) -> list:
    llm = ChatGoogleGenerativeAI(
        model="gemini-1.5-pro",
        temperature=0,
        max_tokens=None,
        timeout=None,
        max_retries=2,
        backoff_factor=2,
        verbose=True,
        streaming=True,
    )

    prompt = ChatPromptTemplate.from_messages(
        [("system", PROMPT), ("human", "{input_text}")]
    )

    chain = prompt | llm
    ai_response = chain.invoke({"input_text": input_text})

    slides_json = json.loads(ai_response.content)
    return slides_json

# Step 3: Create PowerPoint from JSON
def create_ppt_from_json(slides_json: list, output_file: str):
    prs = Presentation()
    for slide_data in slides_json:
        if slide_data.get("is_title_slide", "no") == "yes":
            slide_layout = prs.slide_layouts[0]
            slide = prs.slides.add_slide(slide_layout)
            title = slide.shapes.title
            subtitle = slide.placeholders[1]
            title.text = slide_data.get("title_text", "")
            subtitle.text = slide_data.get("subtitle_text", "")
        else:
            slide_layout = prs.slide_layouts[1]
            slide = prs.slides.add_slide(slide_layout)
            title = slide.shapes.title
            body = slide.shapes.placeholders[1].text_frame
            title.text = slide_data.get("title_text", "")
            for bullet in slide_data.get("text", []):
                p = body.add_paragraph()
                p.text = bullet
    prs.save(output_file)

# Step 4: Generate narration audio
def generate_slide_audio(slides_json, audio_folder):
    audio_files = []
    audio_durations = []

    llm = ChatGoogleGenerativeAI(model="gemini-1.5-pro", temperature=0.5, max_tokens=150)
    
    for slide in slides_json:
        title_text = slide.get('title_text', '')
        content_list = slide.get('text', [])
        text_to_speak = f"{title_text}. " + ". ".join(content_list) + "."

        audio_prompt = f"Create a voice-over script based on the following slide content:\n\nSlide Title: {title_text}\ntext_to_speak: {text_to_speak}\n"

        prompt = ChatPromptTemplate.from_messages([("system", audio_prompt), ("human", text_to_speak)])
        chain = prompt | llm
        raw_audio_response = chain.invoke({"text_to_speak": text_to_speak})

        if raw_audio_response and raw_audio_response.content:
            narration_text = raw_audio_response.content.strip()
            audio_file_path = os.path.join(audio_folder, f"audio_slide_{slide['id']}.mp3")
            tts = gTTS(text=narration_text, lang="en", slow=False)
            tts.save(audio_file_path)
            audio_files.append(audio_file_path)
            audio_clip = AudioFileClip(audio_file_path)
            audio_durations.append(audio_clip.duration)

    return audio_files, audio_durations

# Step 5: Convert PowerPoint to images
def ppt_to_images(ppt_file, output_folder):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    pythoncom.CoInitialize()
    powerpoint = comtypes.client.CreateObject("PowerPoint.Application")
    powerpoint.Visible = 1
    presentation = powerpoint.Presentations.Open(ppt_file)

    slide_images = []
    for i, slide in enumerate(presentation.Slides):
        slide_image_path = os.path.join(output_folder, f"slide_{i + 1}.png")
        slide.Export(slide_image_path, "PNG")
        slide_images.append(slide_image_path)

    presentation.Close()
    powerpoint.Quit()
    pythoncom.CoUninitialize()

    return slide_images

# Step 6: Create video from slides and audio
def create_video_from_slides(slide_images, audio_files, audio_durations, output_video_path):
    image_clips = []

    for img, audio_file, duration in zip(slide_images, audio_files, audio_durations):
        audio_clip = AudioFileClip(audio_file)
        image_clip = ImageClip(img).set_duration(duration)
        image_clip = image_clip.set_audio(audio_clip)
        image_clips.append(image_clip)

    final_video = concatenate_videoclips(image_clips, method="compose")
    final_video.write_videofile(output_video_path, fps=24)

# Main Streamlit app
def main():
    st.title("YouTube Transcript to Video Generator")

    # Step 1: YouTube Search
    query = st.text_input("Enter your YouTube search query:")
    
    if query:
        results = youtube_search(query, max_results=5)
        transcripts = []

        if results:
            for i, result in enumerate(results):
                st.subheader(f"Video {i+1}")
                st.write(f"Title: {result['title']}")
                st.write(f"URL: {result['url']}")
                video_id = result['video_id']

                # Get transcript
                with st.spinner("Fetching transcript..."):
                    transcript = get_transcript(video_id)
                    if transcript:
                        st.text_area(f"Transcript {i+1}", transcript, height=150)
                        transcripts.append(transcript)

        if transcripts:
            combined_transcript = " ".join(transcripts)

            # Step 2: Summarize Transcript
            with st.spinner("Summarizing transcript..."):
                summarized_text = summarize_transcripts(combined_transcript)
                st.write("Summarized Text:", summarized_text)

            # Step 3: Generate PPT JSON
            with st.spinner("Generating presentation slides..."):
                slides_json = generate_ppt_json(summarized_text)

                st.json(slides_json)

                # Step 4: Create PPT
                with tempfile.NamedTemporaryFile(suffix=".pptx", delete=False) as ppt_temp:
                    create_ppt_from_json(slides_json, ppt_temp.name)
                    st.write("Download PowerPoint:", ppt_temp.name)

                # Step 5: Generate Audio for Slides
                with tempfile.TemporaryDirectory() as audio_dir:
                    audio_files, audio_durations = generate_slide_audio(slides_json, audio_dir)

                    # Step 6: Convert PPT to Images
                    with tempfile.TemporaryDirectory() as img_dir:
                        slide_images = ppt_to_images(ppt_temp.name, img_dir)

                        # Step 7: Create Video from Slides and Audio
                        with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as video_temp:
                            create_video_from_slides(slide_images, audio_files, audio_durations, video_temp.name)
                            st.write("Download Video:", video_temp.name)

if __name__ == "__main__":
    main()
